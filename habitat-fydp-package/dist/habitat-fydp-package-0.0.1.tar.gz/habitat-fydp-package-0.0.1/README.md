# habitat-fydp-package

### Purpose of the Package
Democratize access to HAB related data in Lake Erie to be used for scientific research

### Features

### Getting Started

### Usage 

### API References

### Contribution 

### Author